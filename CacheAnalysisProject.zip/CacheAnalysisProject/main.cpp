#include <iostream>
#include <fstream>
#include <string>
#include <iomanip>
#include <math.h>
#include <map>
#include <vector>
#include <algorithm>
#include <queue>

using namespace std;

/// Assignment completed by Ryan Coveny, UF ID 3495-4252.

class CacheAnalysis {
public:
    float directMapping(int fileInput, int cacheSize, int numBlockBytes);
    float setAssociative(int fileInput, int setAssociation, int replacementMethod, int cacheSize, int numBlockBytes);
    float fullyAssociative(int fileInput, int replacementMethod, int cacheSize, int numBlockBytes);
    void openFile(int fileInput, ifstream& myFile);
    string parseInput(string s);
    string hexToBinary(string s);
    string binaryToDecimal(string s);
};

/// Main Three Function Calls:
// Perform a direct mapped cache simulation.
float CacheAnalysis::directMapping(int fileInput, int cacheSize, int numBlockBytes) {
    // Open the chosen file
    ifstream myFile;
    openFile(fileInput, myFile);
    if (myFile.is_open()) {
        // Initialize cache structure with all default values.
        int numLines = cacheSize/numBlockBytes;
        // Data structure is a vector of vectors, inner holds 3 values: (0)set, (1)tag, (2)counter.
        vector<vector<int>> cache;
        vector<int> defaultInput = {-1, -1, 0};
        for (int i = 0; i < numLines; i++) {
            cache.push_back(defaultInput);
        }

        // Set default hitCounts and actionCounts
        float hitCount = 0.00;
        float actionCount = 0.00;
        string currentLine = "";
        while (myFile.good()) {
            // Read through the chosen file and add each line of that file to the cache.
            getline(myFile, currentLine);
            if (currentLine != "") {
                actionCount++;
                // Extract hexadecimal code with parseInput, determine widths of offset and line.
                currentLine = parseInput(currentLine);
                int offsetWidth = log2(numBlockBytes);
                int lineWidth = log2(numLines);

                // Determine values of the line and tag via substrings using binary and decimal conversions.
                string fullBinary = hexToBinary(currentLine);
                string tagBinary = fullBinary.substr(0, fullBinary.size() - offsetWidth - lineWidth);
                string lineBinary = fullBinary.substr(fullBinary.size() - offsetWidth - lineWidth, lineWidth);
                int line = stoi(binaryToDecimal(lineBinary));
                int tag = stoi(binaryToDecimal(tagBinary));

                if (cache[line][1] == tag) {
                    // Hit found - already exists in map.
                    cache[line][2] = 0;
                    hitCount++;
                }
                else {
                    // Miss: Add block to cache. Replaces already existing/default vector in that position.
                    cache[line] = {line, tag, 1};
                }
            }
        }
        return hitCount/actionCount;
    }
    return 0;
}
// Perform a set associative cache simulation.
float CacheAnalysis::setAssociative(int fileInput, int setAssociation, int replacementMethod, int cacheSize, int numBlockBytes) {
    // Open the chosen file
    ifstream myFile;
    openFile(fileInput, myFile);
    if (myFile.is_open()) {
        int numLines = cacheSize/numBlockBytes;
        // Initialize the cache with all default values. Also determine the number of sets in the cache based on the set association.
        vector<vector<int>> cache;
        vector<int> defaultInput;
        int count = 0;
        int setNum = 0;
        for (int i = 0; i < numLines; i++) {
            defaultInput = {setNum, -1, 0};
            cache.push_back(defaultInput);
            count++;
            if (count == setAssociation) {
                setNum++;
                count = 0;
            }
        }
        // Initialize the queue used for the First In First Out replacement strategy.
        vector<queue<int>> fifo;
        queue<int> defaultQueue;
        for (int i = 0; i < setNum; i++) {
            fifo.push_back(defaultQueue);
        }

        // Set default hitCounts and actionCounts
        float hitCount = 0.00;
        float actionCount = 0.00;
        string currentLine = "";
        while (myFile.good()) {
            getline(myFile, currentLine);
            if (currentLine != "") {
                actionCount++;
                // Since new input must interact with cache, iterate counter for all non-default nodes by one.
                for (int i = 0; i < cache.size(); i++) {
                    if (cache[i][0] != -1) {
                        cache[i][2]++;
                    }
                }

                // Extract hexadecimal code with parseInput, determine widths of offset, set, and tag.
                currentLine = parseInput(currentLine);
                // Convert the full hexadecimal value to binary for use in determining tagWidth as well as to attain the substrings in the next section.
                string fullBinary = hexToBinary(currentLine);
                int offsetWidth = log2(numBlockBytes);
                int setWidth = log2(numLines/setAssociation);
                int tagWidth = fullBinary.size() - offsetWidth - setWidth;

                // Determine the values of the set and tag using substrings with binary to decimal conversions.
                string tagBinary = fullBinary.substr(0, tagWidth);
                string setBinary = fullBinary.substr(tagWidth, setWidth);
                int tag = stoi(binaryToDecimal(tagBinary));
                int set = stoi(binaryToDecimal(setBinary));

                // Find the involved set within the cache.
                int lastSet = -1;
                int firstIndex = 0;
                for (int i = 0; i < cache.size(); i++) {
                    if (cache[i][0] == set) {
                        // Hit found. Already exists in map.
                        if (cache[i][1] == tag) {
                            cache[i][2] = 0;
                            hitCount++;
                            break;
                        }
                        // Empty space to input val within set exists. Miss with input added to cache.
                        else if (cache[i][0] == set && cache[i][1] == -1) {
                            cache[i] = {set, tag, 0};
                            fifo[set].push(i);
                            break;
                        }
                        // Use this if statement to track what the first index of a set is.
                        if (set != lastSet) {
                            lastSet = set;
                            firstIndex = i;
                        }
                        // Miss but need to do LRU or FIFO.
                        if (i + 1 == cache.size() || cache[i + 1][0] != set) {
                            // Perform Least Recently Used replacement. Use counter variable in data structure, replace the one with the highest counter.
                            if (replacementMethod == 1) {
                                int highestCounter = -1;
                                int highestCounterIndex = 0;
                                for (int i = 0; i < setAssociation; i++) {
                                    if (cache[firstIndex + i][2] > highestCounter && cache[firstIndex + i][0] != -1) {
                                        highestCounter = cache[i][2];
                                        highestCounterIndex = firstIndex + i;
                                    }
                                }
                                cache[highestCounterIndex] = {set, tag, 0};
                            }
                            // Perform First In First Out replacement. Remove first member of the current queue from the cache, pop that element from the queue and add the new element to the queue.
                            else {
                                int temp = fifo[set].front();
                                cache[fifo[set].front()] = {set, tag, 0};
                                fifo[set].pop();
                                fifo[set].push(temp);
                            }
                            break;
                        }
                    }
                }
            }
        }
        return hitCount/actionCount;
    }
    return 0;
}
// Perform a fully associative cache simulation.
float CacheAnalysis::fullyAssociative(int fileInput, int replacementMethod, int cacheSize, int numBlockBytes) {
    // Open the selected file.
    ifstream myFile;
    openFile(fileInput, myFile);
    if (myFile.is_open()) {
        // Initialize the cache with all default values.
        int numLines = cacheSize/numBlockBytes;
        vector<vector<int>> cache;
        vector<int> defaultInput = {-1, -1, -1};
        for (int i = 0; i < numLines; i++) {
            cache.push_back(defaultInput);
        }

        // Initialize the hit count, action count, and queue used for First In First Out replacement.
        float hitCount = 0.00;
        float actionCount = 0.00;
        string currentLine = "";
        queue<int> fifo;
        while (myFile.good()) {
            getline(myFile, currentLine);
            // Function to parse what is important and another to convert that important bit to decimal.
            if (currentLine != "") {
                actionCount++;
                // Parse the file's input, establish the widths of the offset and line.
                currentLine = parseInput(currentLine);
                int offsetWidth = log2(numBlockBytes);
                int lineWidth = log2(numLines);

                // Attain substrings for the tag and line also using binary and decimal conversions. Attain the value of the tag.
                string fullBinary = hexToBinary(currentLine);
                string tagBinary = fullBinary.substr(0, fullBinary.size() - offsetWidth);
                string lineBinary = fullBinary.substr(fullBinary.size() - offsetWidth, lineWidth);
                int tag = stoi(binaryToDecimal(tagBinary));

                bool hitOrSpaceFound = false;
                // Increase the counters for all members of the cache.
                for (int i = 0; i < cache.size(); i++) {
                    if (cache[i][0] != -1) {
                        cache[i][2]++;
                    }
                }
                for (int i = 0; i < cache.size(); i++) {
                    if (cache[i][1] == tag && cache[i][0] != -1) {
                        // Hit found - already exists in map.
                        cache[i][2] = 0;
                        hitCount++;
                        hitOrSpaceFound = true;
                        break;
                    }
                    else if (cache[i][0] == -1) {
                        // Miss: Add block to cache. Replaces already existing/default vector in that position. Empty space
                        cache[i] = {0, tag, 0};
                        fifo.push(i);
                        hitOrSpaceFound = true;
                        break;
                    }
                }
                if (!hitOrSpaceFound) {
                    // Perform Least Recently Used replacement. Use counter variable in data structure, replace the one with the highest counter.
                    if (replacementMethod == 1) { // LRU
                        int highestCounter = -1;
                        int highestCounterIndex = 0;
                        for (int i = 0; i < cache.size(); i++) {
                            if (cache[i][2] > highestCounter && cache[i][0] != -1) {
                                highestCounter = cache[i][2];
                                highestCounterIndex = i;
                            }
                        }
                        cache[highestCounterIndex] = {0, tag, 0};
                    }
                    // Perform First In First Out replacement. Remove first member of the current queue from the cache, pop that element from the queue and add the new element to the queue.
                    else {
                        int temp = fifo.front();
                        cache[fifo.front()] = {0, tag, 0};
                        fifo.pop();
                        fifo.push(temp);
                    }
                }
            }
        }
        return hitCount/actionCount;
    }
    return 0;
}

/// Helper Functions:
// Read chosen file, add contents to cache data structure.
void CacheAnalysis::openFile(int fileInput, ifstream& myFile) {
    switch(fileInput) {
        case 1: {
            myFile.open("gcc.trace");
            break;
        }
        case 2: {
            myFile.open("read01.trace");
            break;
        }
        case 3: {
            myFile.open("read02.trace");
            break;
        }
        case 4: {
            myFile.open("read03.trace");
            break;
        }
        case 5: {
            myFile.open("shane.trace");
            break;
        }
        case 6: {
            myFile.open("swim.trace");
            break;
        }
        case 7: {
            myFile.open("write01.trace");
            break;
        }
        case 8: {
            myFile.open("write02.trace");
            break;
        }
    }
}
// Turn lines from input files into readable forms.
string CacheAnalysis::parseInput(string s) {
    string delimiter = " ";
    string result = s.substr(4);
    result = result.substr(0, result.size()-2);
    return result;
}
// Convert hexadecimal to binary.
string CacheAnalysis::hexToBinary(string s) {
    string result = "";
    char currentChar;
    for (int i = 0; i < s.size(); i++) {
        currentChar = toupper(s[i]);
        switch(currentChar) {
            case '0': {
                result.append("0000");
                break;
            }
            case '1': {
                result.append("0001");
                break;
            }
            case '2': {
                result.append("0010");
                break;
            }
            case '3': {
                result.append("0011");
                break;
            }
            case '4': {
                result.append("0100");
                break;
            }
            case '5': {
                result.append("0101");
                break;
            }
            case '6': {
                result.append("0110");
                break;
            }
            case '7': {
                result.append("0111");
                break;
            }
            case '8': {
                result.append("1000");
                break;
            }
            case '9': {
                result.append("1001");
                break;
            }
            case 'A': {
                result.append("1010");
                break;
            }
            case 'B': {
                result.append("1011");
                break;
            }
            case 'C': {
                result.append("1100");
                break;
            }
            case 'D': {
                result.append("1101");
                break;
            }
            case 'E': {
                result.append("1110");
                break;
            }
            case 'F': {
                result.append("1111");
                break;
            }
        }
    }
    return result;
}
// Convert binary to decimal.
string CacheAnalysis::binaryToDecimal(string s) {
    int currentNum = 0;
    int total = 0;
    int i = 0;
    for (int j = s.size() - 1; j >= 0; j--) {
        if (s[i] == '0') {
            currentNum = 0;
        }
        else {
            currentNum = 1;
        }
        total += currentNum * pow(2, j);
        i++;
    }
    return to_string(total);
}

int main() {
    CacheAnalysis cacheCall;

    cout << "What analysis method?\n" << "1 Direct Mapping\n" << "2 Set Associative\n" << "3 Fully Associative\n"; // Num blocks in each set
    int analysisInput;
    bool continueLoop = true;
    while(continueLoop) {
        cin >> analysisInput;
        if (analysisInput == 1 || analysisInput == 2 || analysisInput == 3) {
            continueLoop = false;
        }
    }

    cout << "Input cache size (Positive power of 2^(your input)).\n";
    int cacheSize = 0;
    int cacheExponent = 0;
    cin >> cacheExponent;
    cacheSize = pow(2, cacheExponent);

    cout << "Input exponent for number of bytes in a block (Positive power of 2^(your input)).\n"; // Positive power of 2, must be at least 4
    int numBlockBytes = 2;
    int blockExponent = 0;
    cin >> blockExponent;
    numBlockBytes = pow(2, blockExponent);

    int replacementMethod = 0;
    if (analysisInput !=  1) {
        cout << "What replacement method?\n" << "1. Least Recently Used (LRU)\n" << "2. First in, first out (FIFO)\n";
        continueLoop = true;
        while (continueLoop) {
            cin >> replacementMethod;
            if (replacementMethod == 1 || replacementMethod == 2) {
                continueLoop = false;
            }
        }
    }

    cout << "Which file to read?\n" << "1 gcc\n" << "2 read01\n" << "3 read02\n"<< "4 read03\n" << "5 shane\n" << "6 swim\n" << "7 write01\n" << "8 write02\n";
    int fileInput = 0;
    continueLoop = true;
    while(continueLoop) {
        cin >> fileInput;
        if (fileInput >= 1 && fileInput <= 8) {
            continueLoop = false;
        }
    }

    if (analysisInput == 1) {
        cout << "Hit Rate: " << cacheCall.directMapping(fileInput, cacheSize, numBlockBytes) << endl;
    }
    else if (analysisInput == 2) {
        cout << "Input how many tags can fit in a set (n for n-way set association).\n"; // Positive power of 2, must be at least 4
        int setAssociation = 0;
        continueLoop = true;
        while (continueLoop) {
            cin >> setAssociation;
            if (setAssociation > 0) {
                continueLoop = false;
            }
        }
        cout << "Hit Rate: " << cacheCall.setAssociative(fileInput, setAssociation, replacementMethod, cacheSize, numBlockBytes) << endl;;
    }
    else {
        cout << "Hit Rate: " << cacheCall.fullyAssociative(fileInput, replacementMethod, cacheSize, numBlockBytes) << endl;;
    }
    return 0;
}
